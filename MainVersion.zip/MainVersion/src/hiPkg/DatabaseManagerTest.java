package hiPkg;

import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class DatabaseManagerTest {
	
//	private static Connection conn = new ConnectionManager(user, password).getConnection();
//	
//	   // assigning the values
//	   protected void setUp(){
//	      int value1 = 3;
//	      int value2 = 3;
//	   }
//
//	   // test method to add two values
//	   public void testAdd(){
//	      double result = value1 + value2;
//	      assertTrue(result == 6);
//	   }
//	@Test
//	public void testIsUniqueEmail() {
//		assertTrue(result == 6);
//	}
//
//	@Test
//	public void testDeletePolicy() {
//		fail("Not yet implemented");
//	}

}
